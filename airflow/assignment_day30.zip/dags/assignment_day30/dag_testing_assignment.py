from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime, timedelta

#Membuat function extract, transform, load

def extract_data(**kwargs):
    data = [
        {'name': 'apple', 'price':100},
        {'name': 'banana', 'price': 80},
    ]

    #push data ke XCom dengan key 'raw_data'
    kwargs['ti'].xcom_push(key='raw_data', value=data)
    return data

def transform_data(**kwargs):
    #pull data dari XCom
    ti = kwargs['ti']
    data = ti.xcom_pull(key='raw_data', task_ids='extract_task') #extract_task

    #validasi data diterima
    if not data:
        raise ValueError("No data received from extract_task")
    
    #upprcase + prrice with tax
    transformed_data = []
    for item in data:
        transformed_data.append({
            'name': item['name'].upper(),
            'price_with_tax': round(item['price'] * 1.1,2) #derived metric
        })
    #push data ke XCom dengan key 'transformed_data'
    ti.xcom_push(key='transformed_data', value = transformed_data)
    return transformed_data

def load_data(**kwargs):
    #pull data dari XCom
    ti = kwargs['ti']
    data = ti.xcom_pull(key='transformed_data', task_ids='transform_task')
    print("✅ Loaded Data Succesfull. Data:", data)
    return True



#settingan global default args untuk all task
default_args = {
    'owner': 'data-engineering-team',
    'retries': 2,
    'retry_delay': timedelta(minutes=5),
}

#settingan DAG
with DAG(
    dag_id= 'data_validation_dag',
    default_args=default_args,
    description = 'DAG for daily data validation testing',
    schedule_interval= '@daily',
    start_date = datetime(2025,1,1),
    catchup = False,
    tags = ['testing', 'validation', 'dag-testing']
) as dag:
    
    extract_task = PythonOperator(
        task_id= 'extract_task',
        python_callable = extract_data,
        provide_context= True
    )

    transform_task = PythonOperator(
        task_id= 'transform_task',
        python_callable = transform_data,
        provide_context= True
    )

    load_task = PythonOperator(
        task_id = 'load_task',
        python_callable = load_data,
        provide_context= True
    )

    extract_task >> transform_task >> load_task