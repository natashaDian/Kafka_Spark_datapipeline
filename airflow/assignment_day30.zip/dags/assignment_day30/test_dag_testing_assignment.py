import pytest 
from unittest.mock import MagicMock
from dags.assignment_day30.dag_testing_assignment import extract_data, transform_data, load_data
from airflow.models import DagBag

#Menggunakan pytest fixture sesuai soal
@pytest.fixture

# testing mock untuk ti xcom
def ti_Mock():
    ti = MagicMock()
    ti.xcom_push = MagicMock()
    ti.xcom_pull = MagicMock()
    return ti

#testing untuk extract data
def test_extract_data(ti_Mock):
    result = extract_data(ti = ti_Mock)
    assert isinstance(result, list)
    assert 'name' in result[0]
    ti_Mock.xcom_push.assert_called_once_with(key='raw_data', value=result)

#testing untuk transform data
def test_transform_data(ti_Mock):
    sample_data = [{'name': 'apple', 'price': 100}]
    ti_Mock.xcom_pull.return_value = sample_data

    result = transform_data(ti = ti_Mock)
    assert result == [{'name': 'APPLE', 'price_with_tax': 110.0}] #ngecek nama ke upper atau engga dan ngecek derived metric jalan apa ga
    ti_Mock.xcom_push.assert_called_once_with(key='transformed_data', value=result) #ngecek xcom push

#testing untuk load data
def test_load_data(ti_Mock, capsys):
    sample_data = [{'name': 'APPLE', 'price_with_tax': 110.0}]
    ti_Mock.xcom_pull.return_value = sample_data

    result = load_data(ti=ti_Mock)
    assert result is True #ngecek load data return value apa engga

    captured = capsys.readouterr()
    assert "Loaded Data" in captured.out

#testing dag terload atau engga
def test_dag_integrity():
    dagbag = DagBag(dag_folder="dags/", include_examples=False)
    assert not dagbag.import_errors, f"DAG import errors: {dagbag.import_errors}"
    dag = dagbag.get_dag('data_validation_dag')
    assert dag is not None, "DAG 'data_validation_dag' tidak ditemukan."
    assert len(dag.tasks) >= 3, "Jumlah task kurang dari 3"